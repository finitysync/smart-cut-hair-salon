import { Hero } from '../components/Hero';
import { ServicesOverview } from '../components/ServicesOverview';
import { LiveConsultant } from '../components/LiveConsultant';
import { FeaturedServices } from '../components/FeaturedServices';
import { BridalStudio } from '../components/BridalStudio';
import { Mission } from '../components/Mission';
import { Academy } from '../components/Academy';
import { Statistics } from '../components/Statistics';
import { Contact } from '../components/Contact';

export function HomePage() {
  return (
    <>
      <Hero />
      <ServicesOverview />
      <LiveConsultant />
      <FeaturedServices />
      <BridalStudio />
      <Mission />
      <Academy />
      <Statistics />
      <Contact />
    </>
  );
}
