import { motion } from 'motion/react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Calendar } from '../components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { Calendar as CalendarIcon, Clock, MapPin, User, Phone, Mail } from 'lucide-react';
import { useState } from 'react';
import { format } from 'date-fns';

const services = [
  'Haircut & Styling',
  'Hair Color',
  'Beard Grooming',
  'Facial Treatment',
  'Manicure & Pedicure',
  'Bridal Makeup',
  'Full Grooming Package',
  'Other'
];

const locations = [
  'Model Town, Lahore',
  'DHA, Lahore',
  'Gulberg, Lahore',
  'Johar Town, Lahore',
  'Bahria Town, Lahore',
  'F-7, Islamabad',
  'Blue Area, Islamabad',
  'Clifton, Karachi',
  'DHA, Karachi',
  'Faisalabad'
];

const timeSlots = [
  '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
  '12:00 PM', '12:30 PM', '01:00 PM', '01:30 PM',
  '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM',
  '04:00 PM', '04:30 PM', '05:00 PM', '05:30 PM',
  '06:00 PM', '06:30 PM', '07:00 PM', '07:30 PM',
  '08:00 PM', '08:30 PM', '09:00 PM', '09:30 PM'
];

export function BookingPage() {
  const [date, setDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState('');

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-black to-[#1a1a1a] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, rgba(212, 175, 55, 0.3) 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }}></div>
        </div>

        <div className="container mx-auto px-4 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 
              className="mb-4"
              style={{ 
                fontFamily: 'Playfair Display, serif',
                fontSize: 'clamp(2.5rem, 5vw, 4rem)'
              }}
            >
              Book Your Appointment
            </h1>
            <p className="text-white/80 text-xl max-w-2xl mx-auto">
              Schedule your visit and experience premium grooming and beauty services
            </p>
          </motion.div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-20 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="p-8 lg:p-12 border-0 shadow-2xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h2 
                  className="mb-8 text-center"
                  style={{ 
                    fontFamily: 'Playfair Display, serif',
                    fontSize: 'clamp(1.5rem, 3vw, 2rem)'
                  }}
                >
                  Fill in Your Details
                </h2>

                <form className="space-y-6">
                  {/* Personal Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" style={{ color: '#D4AF37' }} />
                          Full Name *
                        </div>
                      </Label>
                      <Input 
                        id="name" 
                        placeholder="Enter your full name"
                        className="rounded-lg"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4" style={{ color: '#D4AF37' }} />
                          Phone Number *
                        </div>
                      </Label>
                      <Input 
                        id="phone" 
                        type="tel"
                        placeholder="03XX-XXXXXXX"
                        className="rounded-lg"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" style={{ color: '#D4AF37' }} />
                        Email Address
                      </div>
                    </Label>
                    <Input 
                      id="email" 
                      type="email"
                      placeholder="your.email@example.com"
                      className="rounded-lg"
                    />
                  </div>

                  {/* Service Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="service">Service Type *</Label>
                    <Select>
                      <SelectTrigger className="rounded-lg">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent>
                        {services.map((service) => (
                          <SelectItem key={service} value={service.toLowerCase().replace(/\s+/g, '-')}>
                            {service}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Location Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="location">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" style={{ color: '#D4AF37' }} />
                        Preferred Location *
                      </div>
                    </Label>
                    <Select>
                      <SelectTrigger className="rounded-lg">
                        <SelectValue placeholder="Select a location" />
                      </SelectTrigger>
                      <SelectContent>
                        {locations.map((location) => (
                          <SelectItem key={location} value={location.toLowerCase().replace(/\s+/g, '-')}>
                            {location}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Date & Time */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>
                        <div className="flex items-center gap-2">
                          <CalendarIcon className="w-4 h-4" style={{ color: '#D4AF37' }} />
                          Preferred Date *
                        </div>
                      </Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left rounded-lg"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date ? format(date, 'PPP') : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={date}
                            onSelect={setDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="time">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" style={{ color: '#D4AF37' }} />
                          Preferred Time *
                        </div>
                      </Label>
                      <Select value={selectedTime} onValueChange={setSelectedTime}>
                        <SelectTrigger className="rounded-lg">
                          <SelectValue placeholder="Select time" />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          {timeSlots.map((time) => (
                            <SelectItem key={time} value={time}>
                              {time}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Additional Notes */}
                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes (Optional)</Label>
                    <Textarea 
                      id="notes"
                      placeholder="Any special requests or preferences..."
                      className="rounded-lg min-h-[100px]"
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="pt-4">
                    <Button 
                      type="submit"
                      size="lg"
                      className="w-full rounded-full"
                      style={{ 
                        background: 'linear-gradient(135deg, #D4AF37 0%, #F4E5C3 100%)',
                        color: '#1a1a1a'
                      }}
                    >
                      Confirm Booking
                    </Button>
                  </div>

                  <p className="text-sm text-gray-500 text-center">
                    * Required fields. Our team will contact you to confirm your appointment.
                  </p>
                </form>
              </motion.div>
            </Card>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="py-20 bg-black text-white">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#F4E5C3] flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-[#1a1a1a]" />
              </div>
              <h3 className="mb-2">Call Us</h3>
              <p className="text-white/70">0322-7999771</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-center"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#F4E5C3] flex items-center justify-center mx-auto mb-4">
                <Mail className="w-8 h-8 text-[#1a1a1a]" />
              </div>
              <h3 className="mb-2">Email Us</h3>
              <p className="text-white/70">info@smartcutofficial.co</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="text-center"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#F4E5C3] flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-[#1a1a1a]" />
              </div>
              <h3 className="mb-2">Opening Hours</h3>
              <p className="text-white/70">Mon - Sun: 10 AM - 10 PM</p>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
