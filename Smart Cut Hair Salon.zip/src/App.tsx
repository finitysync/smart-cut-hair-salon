import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { MensServicesPage } from './pages/MensServicesPage';
import { LadiesServicesPage } from './pages/LadiesServicesPage';
import { PricingPage } from './pages/PricingPage';
import { AboutPage } from './pages/AboutPage';
import { StoreLocatorPage } from './pages/StoreLocatorPage';
import { BlogPage } from './pages/BlogPage';
import { BookingPage } from './pages/BookingPage';
import { StudioPage } from './pages/StudioPage';
import { AcademyPage } from './pages/AcademyPage';

function App() {
  const [currentPage, setCurrentPage] = useState('/');

  useEffect(() => {
    // Simple hash-based routing
    const handleRouteChange = () => {
      const path = window.location.hash.slice(1) || '/';
      setCurrentPage(path);
      window.scrollTo(0, 0);
    };

    // Listen for hash changes
    window.addEventListener('hashchange', handleRouteChange);
    handleRouteChange();

    return () => window.removeEventListener('hashchange', handleRouteChange);
  }, []);

  // Intercept clicks on links to use hash routing
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const link = target.closest('a');
      
      if (link && link.href) {
        const url = new URL(link.href);
        // Only handle internal links (same origin)
        if (url.origin === window.location.origin) {
          const path = url.pathname + url.hash;
          // If it's a page route (not just a hash anchor)
          if (url.pathname !== '/' && url.pathname !== window.location.pathname) {
            e.preventDefault();
            window.location.hash = url.pathname;
          } else if (url.pathname === '/' && !url.hash) {
            e.preventDefault();
            window.location.hash = '/';
          }
        }
      }
    };

    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case '/':
        return <HomePage />;
      case '/services/mens':
        return <MensServicesPage />;
      case '/services/ladies':
        return <LadiesServicesPage />;
      case '/pricing':
        return <PricingPage />;
      case '/about':
        return <AboutPage />;
      case '/stores':
        return <StoreLocatorPage />;
      case '/blog':
        return <BlogPage />;
      case '/booking':
        return <BookingPage />;
      case '/studio':
        return <StudioPage />;
      case '/academy':
        return <AcademyPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
}

export default App;
